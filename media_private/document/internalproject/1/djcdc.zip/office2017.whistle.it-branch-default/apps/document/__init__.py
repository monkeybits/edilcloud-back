# -*- coding: utf-8 -*-
from application_settings import provide_default_settings


provide_default_settings(__name__)
