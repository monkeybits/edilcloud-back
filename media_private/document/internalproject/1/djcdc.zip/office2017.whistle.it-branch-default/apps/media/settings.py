# -*- coding: utf-8 -*-

MEDIA_PHOTO_CONTENT_TYPE_LIMIT_CHOICES_TO = [
    {'app_label': 'project', 'model': 'project'},
    {'app_label': 'profile', 'model': 'company'},
    {'app_label': 'quotation', 'model': 'bom'},
]

MEDIA_VIDEO_CONTENT_TYPE_LIMIT_CHOICES_TO = [
    {'app_label': 'project', 'model': 'project'},
    {'app_label': 'profile', 'model': 'company'},
    {'app_label': 'quotation', 'model': 'bom'},
]
