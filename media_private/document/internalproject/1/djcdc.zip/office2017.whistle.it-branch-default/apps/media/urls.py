# coding: utf-8

from django.conf.urls import url, include


urlpatterns = [
    # url(r'^api/backend/', include('media.api.backend.urls', namespace='api_backend')),
    # url(r'^api/frontend/', include('media.api.frontend.urls', namespace='api_frontend')),
]
