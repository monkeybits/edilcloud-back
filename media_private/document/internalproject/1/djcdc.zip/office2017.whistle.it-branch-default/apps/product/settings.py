# -*- coding: utf-8 -*-

PRODUCT_TYPOLOGY_NAMES = (
    ('A', u'INFRASTRUTTURE e OPERE SPECIALI',),
    ('B', u'EDILE',),
    ('C', u'OPERE COMPLEMENTARI',),
    ('D', u'IMPIANTISTICA',),
)