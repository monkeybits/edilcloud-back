# coding: utf-8

from django.conf.urls import url, include


urlpatterns = [
    # url(r'^api/backend/', include('product.api.backend.urls', namespace='api_backend')),
    # url(r'^api/frontend/', include('product.api.frontend.urls', namespace='api_frontend')),
]
