# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from application_settings import provide_default_settings


provide_default_settings(__name__)

default_app_config = 'apps.project.ProjectConfig'
