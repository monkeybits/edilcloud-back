# -*- coding: utf-8 -*-


def zerofill(x, width=6):
    return "%0*d" % (width, x)
