# -*- coding: utf-8 -*-

# Put here your production specific settings

ADMINS = [
    ('THUX Team', 'jumbo@thux.it'),
]
EMAIL_SUBJECT_PREFIX = '[WHISTLE]'
REST_FRAMEWORK_DOCS = {
    'HIDE_DOCS': True
}
