$( document ).ready(function() {
     if ($( "#searchbar" ).length != 0){
        $('#searchbar').prop('placeholder', 'Name, Slug, SSN, URL, Email');
     }
});