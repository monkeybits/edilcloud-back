$( document ).ready(function() {
     if ($( "#searchbar" ).length != 0){
        $('#searchbar').prop('placeholder', 'User, Company, Role, Language, LastName, FirstName');
     }
});