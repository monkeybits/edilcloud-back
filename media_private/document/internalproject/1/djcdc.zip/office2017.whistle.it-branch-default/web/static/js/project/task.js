$( document ).ready(function() {
     if ($( "#searchbar" ).length != 0){
        $('#searchbar').prop('placeholder', 'Project, Name, Assigned Company');
     }
});